package config;

import org.openqa.selenium.WebDriver;

public class env {
    public static WebDriver driver;
    public static String url = "https://opensource-demo.orangehrmlive.com/";

}
