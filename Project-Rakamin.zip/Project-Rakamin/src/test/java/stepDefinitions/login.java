package stepDefinitions;

import config.env;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import objectRepository.loginPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import static org.junit.Assert.assertTrue;
import static config.env.driver;

public class login {
    WebDriver driver;

    @Given("I am on the SauceDemo login page")
    public void i_am_on_the_SauceDemo_login_page() {
        // Implementasi untuk membuka halaman login
        driver.get("https://www.saucedemo.com/");
    }

    @When("I enter valid username and password")
    public void i_enter_valid_username_and_password() {
        // Implementasi untuk memasukkan username dan password valid
        WebElement usernameField = driver.findElement(By.id("user-name"));
        usernameField.sendKeys("standard_user");
        WebElement passwordField = driver.findElement(By.id("password"));
        passwordField.sendKeys("secret_sauce");
    }

    @When("I enter invalid username and password")
    public void i_enter_invalid_username_and_password() {
        // Implementasi untuk memasukkan username dan password invalid
        WebElement usernameField = driver.findElement(By.id("user-name"));
        usernameField.sendKeys("invalid_user");
        WebElement passwordField = driver.findElement(By.id("password"));
        passwordField.sendKeys("invalid_password");
    }

    @When("I click the Login button")
    public void i_click_the_Login_button() {
        // Implementasi untuk mengklik tombol Login
        WebElement loginButton = driver.findElement(By.id("login-button"));
        loginButton.click();
    }

    @Then("I should be logged in")
    public void i_should_be_logged_in() {
        // Implementasi untuk memeriksa apakah login berhasil
        assertTrue(driver.getCurrentUrl().contains("/inventory.html"));
    }

    @Then("I should see an error message")
    public void i_should_see_an_error_message() {
        // Implementasi untuk memeriksa pesan kesalahan
        WebElement errorMessage = driver.findElement(By.cssSelector("h3[data-test='error']"));
        assertTrue(errorMessage.isDisplayed());
    }
}
